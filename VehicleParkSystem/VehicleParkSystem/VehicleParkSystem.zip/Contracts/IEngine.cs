﻿namespace VehicleParkSystem.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
